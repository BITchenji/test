class Solution:
    def maxAreaOfIsland(self, grid):
        max_area = 0
        row = len(grid)    # 行数
        col = len(grid[0]) # 列数
        visited = [[False] * col for i in range(row)]

        for i in range(row):
            for j in range(col):
                if grid[i][j] == 1 and visited[i][j] == False:
                    # max_area = max(max_area, self.dfs(i, j, grid, visited))
                    if self.dfs(i, j, grid, visited) >= 4:
                        print(i,j)
        # return max_area


    def dfs(self, x, y, grid, visited):
        area = 1
        directions = [[1,0], [0,-1], [-1,0], [0,1]]
        def in_grid(x, y):
            return 0<= x <len(grid) and 0<= y <len(grid[0])

        visited[x][y] = True
        for i in range(4):
            next_x = x + directions[i][0]
            next_y = y + directions[i][1]
            if in_grid(next_x, next_y):
                if visited[next_x][next_y] == False and grid[next_x][next_y] == 1:
                    area += self.dfs(next_x, next_y, grid, visited)
        return area

if __name__ == '__main__':
    grid = [[1,1,0,0,0],[1,1,0,0,0],[0,0,0,1,1],[0,0,0,1,1]]
    a = Solution()
    a.maxAreaOfIsland(grid)
